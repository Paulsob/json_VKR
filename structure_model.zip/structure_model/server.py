from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import json
import pandas as pd
from datetime import datetime
import re

from .extensions import db

from structure_model.config import (
    OUTPUT_DIR, HISTORY_JSON_DIR, TOTAL_DAYS_IN_MONTH,
    FILE_PATH, TAB_SHEET_NAME, COL_SHIFT_1_INSERT, COL_SHIFT_2_INSERT,
    SCHEDULE_SHEETS
)
from structure_model.driver_scheduler import run_planner as run_planner_for_day

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(BASE_DIR, 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

DRIVER_GRAPH_CACHE = {'mtime': None, 'data': {}}


class Absence(db.Model):
    __tablename__ = "absences"
    id = db.Column(db.Integer, primary_key=True)
    tab_no = db.Column(db.String(50), nullable=False, index=True)
    shift = db.Column(db.Integer, nullable=False) # Добавьте это
    day = db.Column(db.Integer, nullable=False)   # Добавьте это
    reason = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "tab_no": self.tab_no,
            "shift": self.shift,
            "day": self.day,
            "reason": self.reason,
            "created_at": self.created_at.isoformat()
        }


class Route(db.Model):
    """Модель маршрута для хранения информации о расписаниях."""
    __tablename__ = "routes"

    id = db.Column(db.Integer, primary_key=True)
    route_number = db.Column(db.Integer, nullable=False, unique=True, index=True)  # Номер маршрута (9, 55, и т.д.)
    name = db.Column(db.String(255), nullable=True)  # Название маршрута (опционально)
    # Имена листов в data.xlsx для рабочего и выходного дня
    sheet_name_workday = db.Column(db.String(255), nullable=False)
    sheet_name_weekend = db.Column(db.String(255), nullable=False)
    # Пути к файлам расписаний в папке output/
    file_workday = db.Column(db.String(500), nullable=True)  # Расписание_рабочего_дня_{route_number}.xlsx
    file_weekend = db.Column(db.String(500), nullable=True)  # Расписание_выходного_дня_{route_number}.xlsx
    is_active = db.Column(db.Boolean, default=True, nullable=False)  # Активен ли маршрут
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "route_number": self.route_number,
            "name": self.name,
            "sheet_name_workday": self.sheet_name_workday,
            "sheet_name_weekend": self.sheet_name_weekend,
            "file_workday": self.file_workday,
            "file_weekend": self.file_weekend,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

    def get_sheet_name(self, is_weekend: bool) -> str:
        """Возвращает имя листа для рабочего или выходного дня."""
        return self.sheet_name_weekend if is_weekend else self.sheet_name_workday

    def get_filename(self, is_weekend: bool) -> str:
        """Возвращает имя файла расписания для рабочего или выходного дня."""
        if is_weekend:
            return self.file_weekend or f"Расписание_выходного_дня_{self.route_number}.xlsx"
        else:
            return self.file_workday or f"Расписание_рабочего_дня_{self.route_number}.xlsx"


def ensure_db_created():
    """Создать БД и таблицы, если их еще нет. Инициализировать маршруты из Excel."""
    with app.app_context():
        db.create_all()

        # 1. Базовые маршруты (9 и 55) — безопасно, если уже есть
        init_default_routes()

        # 2. Синхронизация всех маршрутов из data.xlsx
        try:
            from structure_model.routes_sync import sync_routes
            sync_routes(
                sheet_names=None,          # читать имена листов из data.xlsx
                excel_file=FILE_PATH,
                output_dir=OUTPUT_DIR,
                commit_missing_files=False
            )
            app.logger.info("Маршруты успешно синхронизированы из data.xlsx")
        except Exception as e:
            app.logger.error(f"Ошибка при sync_routes: {e}")


def load_absences():
    ensure_db_created()
    records = Absence.query.order_by(Absence.created_at.desc()).all()
    return [r.to_dict() for r in records]


# Исправленная версия в server.py
def save_absences(absences_list):
    """
    Эта функция больше не нужна, если мы используем db.session.add().
    Но если вы хотите оставить её для совместимости:
    """
    pass


@app.route('/submit-absence', methods=['POST'])
def submit_absence():
    data = request.json
    try:
        # Создаем ОДНУ новую запись в БД
        new_absence = Absence(
            tab_no=str(data.get('tab_no')).strip(),
            shift=int(data.get('shift')),
            day=int(data.get('day')),
            reason=str(data.get('reason'))
        )
        db.session.add(new_absence)
        db.session.commit()

        # Пересчитываем расписание
        day = int(data.get('day'))
        prev_day = max(day - 1, 0)
        routes = get_all_routes()
        for route_obj in routes:
            run_planner_for_day(day, prev_day, route_obj.route_number)

        return jsonify({'success': True, 'message': 'Отсутствие добавлено и расписание обновлено'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/delete-absence', methods=['POST'])
def delete_absence():
    data = request.json or {}
    record_id = data.get('id')  # Теперь это реальный ID из БД

    absence = Absence.query.get(record_id)
    if not absence:
        return jsonify({'success': False, 'error': 'Запись не найдена'}), 404

    day = absence.day
    db.session.delete(absence)
    db.session.commit()

    # Пересчет после удаления
    try:
        prev_day = max(day - 1, 0)
        for route_obj in get_all_routes():
            run_planner_for_day(day, prev_day, route_obj.route_number)
    except Exception as e:
        app.logger.error(f"Ошибка пересчета: {e}")

    return jsonify({'success': True})


def _normalize_tab_no(value):
    if pd.isna(value):
        return None
    try:
        return str(int(float(value)))
    except (ValueError, TypeError):
        text = str(value).strip()
        return text or None


def load_driver_graph_map():
    global DRIVER_GRAPH_CACHE
    try:
        mtime = os.path.getmtime(FILE_PATH)
    except OSError:
        return {}

    if DRIVER_GRAPH_CACHE['mtime'] == mtime and DRIVER_GRAPH_CACHE['data']:
        return DRIVER_GRAPH_CACHE['data']

    try:
        df = pd.read_excel(FILE_PATH, sheet_name=TAB_SHEET_NAME)
    except Exception:
        DRIVER_GRAPH_CACHE = {'mtime': mtime, 'data': {}}
        return {}

    if df.empty:
        DRIVER_GRAPH_CACHE = {'mtime': mtime, 'data': {}}
        return {}

    tab_col = df.columns[0]
    graph_col = df.columns[1] if len(df.columns) > 1 else None
    mapping = {}
    for _, row in df.iterrows():
        tab_no = _normalize_tab_no(row[tab_col])
        if not tab_no:
            continue
        if graph_col is not None and pd.notna(row[graph_col]):
            graph_value = str(row[graph_col]).strip()
        else:
            graph_value = ""
        mapping[tab_no] = graph_value

    DRIVER_GRAPH_CACHE = {'mtime': mtime, 'data': mapping}
    return mapping


@app.route('/')
def dashboard():
    report_path = os.path.join(OUTPUT_DIR, "Отчет_Нагрузки_Дни_1_по_30.xlsx")
    base_count = 0
    if os.path.exists(report_path):
        df = pd.read_excel(report_path, index_col=0)
        base_count = len(df)

    real_absences = load_absences()
    unique_absent_drivers = len(set(item['tab_no'] for item in real_absences))
    statistical_absent = round(base_count * 0.217)
    total_drivers_real = base_count + unique_absent_drivers

    return render_template('dashboard.html',
                           base_count=base_count,
                           statistical_absent=statistical_absent,
                           real_absent=unique_absent_drivers,
                           total_drivers_real=total_drivers_real,
                           total_drivers_stat=base_count + statistical_absent)


@app.route('/calendar-data')
def calendar_data():
    days_with_schedules = []
    for day in range(1, TOTAL_DAYS_IN_MONTH + 1):
        schedule_file = f"Расписание_Итог_{day}.xlsx"
        if os.path.exists(os.path.join(OUTPUT_DIR, schedule_file)):
            days_with_schedules.append(day)
    return jsonify(days_with_schedules)


@app.route('/api/recalculate/<int:day>', methods=['POST'])
def api_recalculate(day):
    if day < 1 or day > TOTAL_DAYS_IN_MONTH:
        return jsonify({'error': 'Некорректный день месяца'}), 400

    data = request.get_json(silent=True) or {}
    allow_weekend = bool(data.get('allow_weekend'))
    route = data.get('route')

    try:
        # prev_day = day - 1, история за день до
        prev_day = max(day - 1, 0)
        # временно меняем флаг через config, если он есть
        from structure_model import config as cfg
        old_value = getattr(cfg, 'ALLOW_WEEKEND_EXTRA_WORK', False)
        cfg.ALLOW_WEEKEND_EXTRA_WORK = allow_weekend

        try:
            # Если маршрут не передан, используем поведение как раньше (ROUTE_NUMBER из конфига)
            if route is None:
                run_planner_for_day(day, prev_day)
            else:
                try:
                    route_int = int(route)
                except ValueError:
                    route_int = None
                if route_int is not None:
                    run_planner_for_day(day, prev_day, route_int)
                else:
                    run_planner_for_day(day, prev_day)
        finally:
            cfg.ALLOW_WEEKEND_EXTRA_WORK = old_value

        return jsonify({'success': True, 'day': day, 'allow_weekend': allow_weekend})
    except Exception as e:
        return jsonify({'error': f'Ошибка при пересчете расписания: {str(e)}'}), 500


import datetime  # добавь в начало файла, если еще нет


@app.route('/api/schedule/<int:day>')
def api_schedule(day):
    if day < 1 or day > TOTAL_DAYS_IN_MONTH:
        return jsonify({'error': 'Некорректный день месяца'}), 400

    route = request.args.get('route', '55').strip()
    try:
        route_int = int(route)
    except ValueError:
        return jsonify({'error': f'Некорректный номер маршрута: {route}'}), 400
    
    # Проверяем, существует ли маршрут в БД
    route_obj = get_route_by_number(route_int)
    if not route_obj:
        # Получаем список доступных маршрутов для сообщения об ошибке
        all_routes = get_all_routes()
        available = [str(r.route_number) for r in all_routes]
        return jsonify({
            'error': f'Маршрут {route} не найден. Доступны: {", ".join(available) if available else "нет активных маршрутов"}'
        }), 400

    # Определяем, выходной ли день
    current_year = datetime.datetime.now().year
    current_month = datetime.datetime.now().month
    try:
        target_date = datetime.date(current_year, current_month, day)
        is_weekend = target_date.weekday() >= 5  # 5=суббота, 6=воскресенье
    except ValueError:
        return jsonify({'error': 'Некорректная дата'}), 400

    # Выбираем файл из БД
    filename = route_obj.get_filename(is_weekend)
    filepath = os.path.join(OUTPUT_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({
            'error': f'Файл расписания не найден: {filename}. '
                    f'Проверьте наличие файлов "Расписание_рабочего_дня_{route}.xlsx" '
                    f'и "Расписание_выходного_дня_{route}.xlsx" в папке output/'
        }), 404

    try:
        # 1) Загружаем базовый шаблон расписания для отображения
        df = pd.read_excel(filepath, sheet_name="Лист1", header=None)

        route_info = ""
        if len(df) > 2 and pd.notna(df.iloc[2, 0]):
            route_info = str(df.iloc[2, 0]).strip()

        rows = []
        for i in range(3, len(df)):
            row = df.iloc[i].fillna('').tolist()
            if any(str(cell).strip() for cell in row):
                rows.append(row)

        if not rows:
            return jsonify({'error': 'Нет данных о рейсах'}), 404

        # 2) Пытаемся дополнительно подгрузить фактические назначения водителей из "Расписание_Итог_<day>.xlsx"
        driver_assignments = []
        driver_graphs = load_driver_graph_map()
        driver_columns = {
            1: max(COL_SHIFT_1_INSERT - 1, 0),
            2: max(COL_SHIFT_2_INSERT - 1, 0)
        }

        # Берём фактические назначения из файлов Расписание_Итог_<day>.xlsx,
        # из того же листа, по которому считали план: SCHEDULE_SHEETS[(route_int, is_weekend)]
        # Т.е. список "Водители на линии" теперь строится именно для выбранного маршрута.
        try:
            route_int = int(route)
        except ValueError:
            route_int = None

        if route_int is not None:
            sheet_name = SCHEDULE_SHEETS.get((route_int, is_weekend))
        else:
            sheet_name = None

        itog_name = f"Расписание_Итог_{day}.xlsx"
        itog_path = os.path.join(OUTPUT_DIR, itog_name)
        if sheet_name and os.path.exists(itog_path):
            try:
                df_itog = pd.read_excel(itog_path, sheet_name=sheet_name, header=None)
                for i in range(3, len(df_itog)):
                    row = df_itog.iloc[i].fillna('').tolist()
                    if not any(str(cell).strip() for cell in row):
                        continue
                    for shift_code, col_idx in driver_columns.items():
                        if col_idx < len(row):
                            tab_no = _normalize_tab_no(row[col_idx])
                            if tab_no:
                                driver_assignments.append({
                                    'shift': shift_code,
                                    'tab_no': tab_no,
                                    'graph_type': driver_graphs.get(tab_no, "")
                                })
            except Exception:
                # Не критично для основного отображения – просто не покажем блок "Водители на линии"
                driver_assignments = []

        # Если по каким‑то причинам не удалось получить назначения из итогового файла
        # (например, для маршрута 9 он ещё не сформирован), пробуем вытащить водителей
        # напрямую из отображаемого файла расписания (рабочего/выходного дня).
        if not driver_assignments:
            try:
                for i in range(3, len(df)):
                    row = df.iloc[i].fillna('').tolist()
                    if not any(str(cell).strip() for cell in row):
                        continue
                    for shift_code, col_idx in driver_columns.items():
                        if col_idx < len(row):
                            tab_no = _normalize_tab_no(row[col_idx])
                            if tab_no:
                                driver_assignments.append({
                                    'shift': shift_code,
                                    'tab_no': tab_no,
                                    'graph_type': driver_graphs.get(tab_no, "")
                                })
            except Exception:
                driver_assignments = []

        return jsonify({
            'success': True,
            'day': day,
            'is_weekend': is_weekend,
            'route': route,
            'route_info': route_info,
            'rows': rows,
            'drivers': driver_assignments
        })

    except Exception as e:
        return jsonify({'error': f'Ошибка при загрузке расписания: {str(e)}'}), 500

@app.route('/get-report')
def get_report():
    filename = "Отчет_Нагрузки_Дни_1_по_30.xlsx"
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)


@app.route('/absence-data')
def absence_data():
    mode = request.args.get('mode', 'statistical')
    report_path = os.path.join(OUTPUT_DIR, "Отчет_Нагрузки_Дни_1_по_30.xlsx")
    base_count = 0

    if os.path.exists(report_path):
        df = pd.read_excel(report_path, index_col=0)
        base_count = len(df)

    real_absences = load_absences()
    unique_absent = len(set(item['tab_no'] for item in real_absences))

    if mode == 'statistical':
        absent_count = round(base_count * 0.217)
        total = base_count + absent_count
        data = {
            'type': 'статистика',
            'absent_count': absent_count,
            'total_drivers': total,
            'details': f'21.7% от {base_count} водителей',
            'note': 'Это число выведено эмпирическим путем. Не стоит ему полностью доверять'
        }
    else:
        total = base_count + unique_absent
        data = {
            'type': 'реальные данные',
            'absent_count': unique_absent,
            'total_drivers': total,
            'details': f'Уникальных водителей введено: {unique_absent}',
            'note': ''
        }

    data['base_count'] = base_count
    return jsonify(data)


@app.route('/submit-absence', methods=['POST'])
def submit_absence():
    data = request.json
    tab_no = data.get('tab_no')
    shift = data.get('shift')
    day = data.get('day')
    reason = data.get('reason')

    if not all([tab_no, shift, day, reason]):
        return jsonify({'error': 'Все поля обязательны'}), 400

    try:
        shift = int(shift)
        day = int(day)
        reason = int(reason)
        if shift not in [1, 2] or day not in range(1, 32) or reason not in [0, 1, 2]:
            return jsonify({'error': 'Некорректные значения полей'}), 400
    except ValueError:
        return jsonify({'error': 'Некорректные числовые значения'}), 400

    absences = load_absences()
    absences.append({
        'tab_no': tab_no,
        'shift': shift,
        'day': day,
        'reason': reason,
        'timestamp': datetime.datetime.now().isoformat()
    })
    save_absences(absences)

    # После сохранения отсутствия пересчитываем расписание на этот день
    # для всех активных маршрутов, чтобы отсутствующий не попал ни в одну схему.
    try:
        prev_day = max(day - 1, 0)
        routes = get_all_routes()
        for route_obj in routes:
            run_planner_for_day(day, prev_day, route_obj.route_number)
    except Exception as e:
        # Не падаем целиком, но возвращаем предупреждение
        return jsonify({
            'success': False,
            'error': f'Отсутствие сохранено, но не удалось пересчитать расписание: {str(e)}'
        }), 500

    return jsonify({'success': True, 'message': 'Отсутствие добавлено и расписание пересчитано для всех активных маршрутов'})


@app.route('/get-real-absences')
def get_real_absences():
    absences = load_absences()
    # Добавляем простой идентификатор (индекс) для последующего удаления
    result = []
    for idx, item in enumerate(absences):
        entry = dict(item)
        entry['id'] = idx
        result.append(entry)
    return jsonify(result)


@app.route('/delete-absence', methods=['POST'])
def delete_absence():
    data = request.json or {}
    idx = data.get('id')
    if idx is None:
        return jsonify({'success': False, 'error': 'Не передан идентификатор записи'}), 400

    try:
        idx = int(idx)
    except (TypeError, ValueError):
        return jsonify({'success': False, 'error': 'Некорректный идентификатор'}), 400

    absences = load_absences()
    if idx < 0 or idx >= len(absences):
        return jsonify({'success': False, 'error': 'Запись не найдена'}), 404

    removed = absences.pop(idx)
    save_absences(absences)

    # Пытаемся пересчитать расписание на соответствующий день:
    # удалённый водитель снова становится доступным кандидатом
    # для всех активных маршрутов.
    try:
        day = int(removed.get('day'))
        prev_day = max(day - 1, 0)
        routes = get_all_routes()
        for route_obj in routes:
            run_planner_for_day(day, prev_day, route_obj.route_number)
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Запись удалена, но не удалось пересчитать расписание: {str(e)}'
        }), 500

    return jsonify({'success': True, 'message': 'Запись удалена и расписание обновлено для всех активных маршрутов'})


# ==================== API для управления маршрутами ====================

def get_route_by_number(route_number):
    """Получить маршрут по номеру из БД."""
    ensure_db_created()
    return Route.query.filter_by(route_number=route_number, is_active=True).first()


def get_all_routes():
    """Получить все активные маршруты из БД."""
    ensure_db_created()
    return Route.query.filter_by(is_active=True).order_by(Route.route_number).all()


def get_schedule_sheet_name(route_number, is_weekend):
    """Получить имя листа расписания для маршрута из БД (замена SCHEDULE_SHEETS)."""
    route = get_route_by_number(route_number)
    if route:
        return route.get_sheet_name(is_weekend)
    # Fallback на старую логику, если маршрута нет в БД
    return SCHEDULE_SHEETS.get((route_number, is_weekend))


@app.route('/api/routes', methods=['GET'])
def api_get_routes():
    """Получить список всех активных маршрутов."""
    routes = get_all_routes()
    return jsonify([route.to_dict() for route in routes])


@app.route('/api/routes', methods=['POST'])
def api_add_route():
    """Добавить новый маршрут. Ожидает JSON с данными маршрута."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({'error': 'Нет данных'}), 400

    route_number = data.get('route_number')
    if not route_number:
        return jsonify({'error': 'Не указан номер маршрута'}), 400

    try:
        route_number = int(route_number)
    except (ValueError, TypeError):
        return jsonify({'error': 'Номер маршрута должен быть числом'}), 400

    # Проверяем, не существует ли уже такой маршрут
    ensure_db_created()
    existing = Route.query.filter_by(route_number=route_number).first()
    if existing:
        return jsonify({'error': f'Маршрут {route_number} уже существует'}), 400

    # Получаем данные
    name = data.get('name', f'Маршрут {route_number}')
    sheet_name_workday = data.get('sheet_name_workday', f'Расписание_рабочего_дня_{route_number}')
    sheet_name_weekend = data.get('sheet_name_weekend', f'Расписание_выходного_дня_{route_number}')
    file_workday = data.get('file_workday', f'Расписание_рабочего_дня_{route_number}.xlsx')
    file_weekend = data.get('file_weekend', f'Расписание_выходного_дня_{route_number}.xlsx')

    # Создаем запись в БД
    route = Route(
        route_number=route_number,
        name=name,
        sheet_name_workday=sheet_name_workday,
        sheet_name_weekend=sheet_name_weekend,
        file_workday=file_workday,
        file_weekend=file_weekend,
        is_active=True
    )
    db.session.add(route)
    db.session.commit()

    return jsonify({'success': True, 'route': route.to_dict()}), 201


@app.route('/api/routes/<int:route_id>', methods=['PUT'])
def api_update_route(route_id):
    """Обновить информацию о маршруте."""
    ensure_db_created()
    route = Route.query.get(route_id)
    if not route:
        return jsonify({'error': 'Маршрут не найден'}), 404

    data = request.get_json(silent=True)
    if not data:
        return jsonify({'error': 'Нет данных'}), 400

    # Обновляем поля, если они переданы
    if 'name' in data:
        route.name = data['name']
    if 'sheet_name_workday' in data:
        route.sheet_name_workday = data['sheet_name_workday']
    if 'sheet_name_weekend' in data:
        route.sheet_name_weekend = data['sheet_name_weekend']
    if 'file_workday' in data:
        route.file_workday = data['file_workday']
    if 'file_weekend' in data:
        route.file_weekend = data['file_weekend']
    if 'is_active' in data:
        route.is_active = bool(data['is_active'])

    route.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({'success': True, 'route': route.to_dict()})


@app.route('/api/routes/<int:route_id>', methods=['DELETE'])
def api_delete_route(route_id):
    """Удалить маршрут (деактивировать)."""
    ensure_db_created()
    route = Route.query.get(route_id)
    if not route:
        return jsonify({'error': 'Маршрут не найден'}), 404

    route.is_active = False
    db.session.commit()

    return jsonify({'success': True, 'message': f'Маршрут {route.route_number} деактивирован'})


@app.route('/api/routes/upload', methods=['POST'])
def api_upload_route_files():
    """
    Загрузить файлы расписания для маршрута.
    Ожидает:
    - route_number (в JSON или form-data)
    - file_workday (файл Excel)
    - file_weekend (файл Excel, опционально)
    """
    try:
        route_number = request.form.get('route_number') or request.json.get('route_number') if request.is_json else None
        if not route_number:
            return jsonify({'error': 'Не указан номер маршрута'}), 400

        try:
            route_number = int(route_number)
        except (ValueError, TypeError):
            return jsonify({'error': 'Номер маршрута должен быть числом'}), 400

        ensure_db_created()

        # Проверяем, существует ли маршрут
        route = Route.query.filter_by(route_number=route_number).first()
        if not route:
            # Создаем новый маршрут, если его нет
            route = Route(
                route_number=route_number,
                name=f'Маршрут {route_number}',
                sheet_name_workday=f'Расписание_рабочего_дня_{route_number}',
                sheet_name_weekend=f'Расписание_выходного_дня_{route_number}',
                is_active=True
            )
            db.session.add(route)
            db.session.flush()  # Получаем ID

        # Сохраняем файлы
        saved_files = {}
        if 'file_workday' in request.files:
            file = request.files['file_workday']
            if file.filename:
                filename = f"Расписание_рабочего_дня_{route_number}.xlsx"
                filepath = os.path.join(OUTPUT_DIR, filename)
                file.save(filepath)
                route.file_workday = filename
                saved_files['workday'] = filename

        if 'file_weekend' in request.files:
            file = request.files['file_weekend']
            if file.filename:
                filename = f"Расписание_выходного_дня_{route_number}.xlsx"
                filepath = os.path.join(OUTPUT_DIR, filename)
                file.save(filepath)
                route.file_weekend = filename
                saved_files['weekend'] = filename

        route.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Файлы загружены',
            'route': route.to_dict(),
            'saved_files': saved_files
        })

    except Exception as e:
        return jsonify({'error': f'Ошибка при загрузке файлов: {str(e)}'}), 500


def init_default_routes():
    """Инициализировать маршруты по умолчанию (9 и 55) в БД, если их еще нет."""

    default_routes = [
        {
            'route_number': 55,
            'name': 'Маршрут 55',
            'sheet_name_workday': 'Расписание_рабочего_дня_55',
            'sheet_name_weekend': 'Расписание_выходного_дня_55',
            'file_workday': 'Расписание_рабочего_дня_55.xlsx',
            'file_weekend': 'Расписание_выходного_дня_55.xlsx'
        },
        {
            'route_number': 9,
            'name': 'Маршрут 9',
            'sheet_name_workday': 'Расписание_рабочего_дня_9',
            'sheet_name_weekend': 'Расписание_выходного_дня_9',
            'file_workday': 'Расписание_рабочего_дня_9.xlsx',
            'file_weekend': 'Расписание_выходного_дня_9.xlsx'
        }
    ]

    for route_data in default_routes:
        existing = Route.query.filter_by(route_number=route_data['route_number']).first()
        if not existing:
            route = Route(**route_data, is_active=True)
            db.session.add(route)

    db.session.commit()



# === Импорты для send_from_directory ===
from flask import send_from_directory


if __name__ == '__main__':
    app.run(debug=True, port=5000)